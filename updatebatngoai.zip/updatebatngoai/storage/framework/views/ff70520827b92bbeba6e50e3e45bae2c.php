<?php $__env->startSection('seo_support'); ?>
    <title><?php echo e($page->title); ?></title>
    <meta name="description" content="<?php echo e($page->meta_description); ?>">
        <meta property="og:title" content="<?php echo e($page->title); ?>">
        <meta property="og:description" content="<?php echo e($page->meta_description); ?>">
        <meta property="og:url" content="<?php echo e(route('client.page',$page->slug)); ?>">
        <meta name="twitter:title" content=" <?php echo e($page->title); ?>">
        <meta name="twitter:description" content="<?php echo e($page->meta_description); ?>">
    <?php if($page->image): ?>
        <meta property="og:image" content="<?php echo e(asset('storage/'.$page->image)); ?>">
        <meta name="twitter:image" content="<?php echo e(asset('storage/'.$page->image)); ?>">
    <?php else: ?>
        <meta name="twitter:image" content="<?php echo e(asset('assets/seo/title/batdangoai.jpg')); ?>">
        <meta property="og:image" content="<?php echo e(asset('assets/seo/title/batdangoai.jpg')); ?>">
    <?php endif; ?>
        <meta name="twitter:card" content="summary_large_image">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('before_css'); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>


    <!-- Page title -->
    <section id="page-title" data-parallax-image="images/parallax/5.jpg">
        <div class="container">
            <div class="page-title">
                <h1><?php echo e($page->title); ?></h1>
                <span><?php echo e($page->expert); ?></span>
            </div>
        </div>
    </section>
    <!-- end: Page title -->

    <!-- Content -->
    <section id="page-content" class="sidebar-left">
        <div class="container">
            <div class="row">
                <!-- post content -->
                <div class="content col-md-9">

                   <?php echo $page->body; ?>


                </div>
                <!-- end: post content -->

                <!-- Sidebar-->
                <div class="sidebar col-md-3">

                    <!--Tabs with Posts-->
                    <div class="widget ">
                        <h4 class="widget-title">Bài viết mới</h4>
                        <div class="post-thumbnail-list">
                            <?php if(!empty($posts->toArray())): ?>
                            <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="post-thumbnail-entry">
                                <?php if($item->image): ?>
                                    <img src="<?php echo e(asset('storage/'.$item->image)); ?>" alt="">
                                <?php else: ?>
                                    <img alt="Shop product image!"
                                         src="<?php echo e(asset('assets/images/blog/thumbnail/5.jpg')); ?>">
                                <?php endif; ?>
                                <div class="post-thumbnail-content">
                                    <a href="<?php echo e(route('new-detail',$item->slug)); ?>"><?php echo e($item->title); ?></a>
                                    <span class="post-date"><i class="fa fa-clock-o"></i> <?php echo e(Carbon\Carbon::create($item->created_at)->format('d-m-Y')); ?></span>

                                </div>
                            </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endif; ?>
                        </div>
                    </div>
                    <!--End: Tabs with Posts-->

























                    <!--widget newsletter-->












                    <!--end: widget newsletter-->
                </div>

                <!-- end: Sidebar-->
            </div>
        </div>
    </section>
    <!-- end: Content -->



<?php $__env->stopSection(); ?>

<?php echo $__env->make('client.layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/batdango/public_html/resources/views/client/page/detail.blade.php ENDPATH**/ ?>