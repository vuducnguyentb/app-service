<?php $__env->startSection('seo_support'); ?>
    <title><?php echo e(config('batdangoai')['seo']['index-post']['title']); ?></title>
    <meta name="description" content="<?php echo e(config('batdangoai')['seo']['index-post']['description']); ?>">
    <meta property="og:image" content="<?php echo e(asset('assets/seo/title/batdangoai.jpg')); ?>">
    <meta name="twitter:image" content="<?php echo e(asset('assets/seo/title/batdangoai.jpg')); ?>">
    <meta property="og:title" content="<?php echo e(config('batdangoai')['seo']['index-post']['title']); ?>">
    <meta property="og:description" content="<?php echo e(config('batdangoai')['seo']['index-post']['description']); ?>">
    <meta property="og:url" content="<?php echo e(route('news')); ?>">
    <meta name="twitter:title" content="<?php echo e(config('batdangoai')['seo']['index-post']['title']); ?>">
    <meta name="twitter:description" content="<?php echo e(config('batdangoai')['seo']['index-post']['description']); ?>">
    <meta name="twitter:card" content="summary_large_image">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('before_css'); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <!-- Content -->
    <section id="page-content" class="sidebar-right">
        <div class="container">
            <div class="row">
                <!-- post content -->
                <div class="content col-md-9">
                    <!-- Page title -->
                    <div class="page-title">
                        <h1>Tin Tức Bạt Dã Ngoại</h1>
                        <div class="breadcrumb float-left">
                            <ul>
                                <li><a href="/">Trang chủ</a>
                                </li>
                                <li><a href="">Tin tức</a>
                                </li>
                            </ul>
                        </div>
                    </div>
                    <!-- end: Page title -->

                    <?php if(!empty($posts->toArray())): ?>
                    <!-- Blog -->
                    <div id="blog" class="post-thumbnails">
                        <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <!-- Post item-->
                            <div class="post-item">
                                <div class="post-item-wrap">
                                    <div class="post-image">
                                        <a href="<?php echo e(route('new-detail',$post->slug)); ?>">
                                            <?php if($post->image): ?>
                                                <img src="<?php echo e(asset('storage/'.$post->image)); ?>" alt="">
                                            <?php else: ?>
                                                <img alt="" src="<?php echo e(asset('assets/images/blog/12.jpg')); ?>">
                                            <?php endif; ?>
                                        </a>

                                    </div>
                                    <div class="post-item-description">
                                        <span class="post-meta-date"><i class="fa fa-calendar-o"></i><?php echo e(Carbon\Carbon::create($post->created_at)->format('d-m-Y')); ?></span>

                                        <h2><a href="<?php echo e(route('new-detail',$post->slug)); ?>"><?php echo e($post->title); ?>

                                            </a></h2>
                                        <p><?php echo e($post->excerpt); ?></p>






                                    </div>
                                </div>
                            </div>
                            <!-- end: Post item-->
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                    <!-- end: Blog -->

                    <!-- Pagination -->
                    <div class="pagination pagination-simple">
                        <?php echo e($posts->links('vendor.pagination.bootstrap-4', ['foo' => 'bar'])); ?>

                    </div>
                    <!-- end: Pagination -->
                        <?php endif; ?>
                </div>
                <!-- end: post content -->

                <!-- Sidebar-->
                <div class="sidebar col-md-3">
                    <div class="pinOnScroll">
                        <!--Tabs with Posts-->
                        <div class="widget ">
                            <h4 class="widget-title">Bài viết mới</h4>
                            <div class="post-thumbnail-list">
                                <?php if(!empty($randomPosts->toArray())): ?>
                                <?php $__currentLoopData = $randomPosts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="post-thumbnail-entry">
                                    <?php if($item->image): ?>
                                        <img src="<?php echo e(asset('storage/'.$item->image)); ?>" alt="">
                                    <?php else: ?>
                                        <img alt="" src="<?php echo e(asset('assets/images/blog/thumbnail/5.jpg')); ?>">
                                    <?php endif; ?>
                                    <div class="post-thumbnail-content">
                                        <a href="<?php echo e(route('new-detail',$item->slug)); ?>"><?php echo e($item->title); ?></a>
                                        <span class="post-date"><i class="fa fa-clock-o"></i><?php echo e(Carbon\Carbon::create($item->created_at)->format('d-m-Y')); ?></span>
                                    </div>
                                </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php endif; ?>
                            </div>
                        </div>
                        <!--End: Tabs with Posts-->

                        <!-- Combo -->
                        <div class="widget clearfix widget-shop">
                            <?php if(!empty($comboViews->toArray())): ?>
                                <h4 class="widget-title">Combo Thuê Bạt</h4>
                                <?php $__currentLoopData = $comboViews; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="product">
                                        <div class="product-image">
                                            <a href="<?php echo e(route('client.combo-detail',$item->slug)); ?>">
                                                <?php if($item->image): ?>
                                                    <img src="<?php echo e(asset('storage/'.$item->image)); ?>"
                                                         alt="<?php echo e($item->name); ?>"
                                                         width="100%"
                                                    >
                                                <?php else: ?>
                                                    <img alt="<?php echo e($item->name); ?>"
                                                         src="<?php echo e(asset('assets/images/shop/products/1.jpg')); ?>"
                                                         width="100%"
                                                    >
                                                <?php endif; ?>
                                            </a>
                                        </div>
                                        <div class="product-description">
                                            <div class="product-category">
                                                <?php echo e($item->productCategory? $item->productCategory->name : ''); ?>

                                            </div>
                                            <div class="product-title">
                                                <p class="text-primary"><a href="<?php echo e(route('client.combo-detail',$item->slug)); ?>"><?php echo e($item->name); ?></a></p>
                                            </div>
                                            <div class="product-price">
                                                <?php if(!empty($item->productPrices->toArray())): ?>
                                                    <ins><span class="text-danger"><?php echo e(number_format($item->productPrices[0]->price, 0, ',', '.')); ?> VND</span>
                                                    </ins>
                                                <?php else: ?>
                                                    <ins><span class="text-danger">Liên hệ</span></ins>
                                                <?php endif; ?>
                                            </div>
                                            <div class="product-rate">
                                                <i class="fa fa-star"></i>
                                                <i class="fa fa-star"></i>
                                                <i class="fa fa-star"></i>
                                                <i class="fa fa-star"></i>
                                                <i class="fa fa-star-half-o"></i>
                                            </div>
                                        </div>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endif; ?>
                        </div>
                        <!-- end: Combo-->

                        <!-- Product -->
                        <div class="widget clearfix widget-shop">
                            <?php if(!empty($productViews->toArray())): ?>
                                <h4 class="widget-title">Sản phẩm thuê</h4>
                                <?php $__currentLoopData = $productViews; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="product">
                                        <div class="product-image">
                                            <a href="<?php echo e(route('client.product-detail',$item->slug)); ?>">
                                                <?php if($item->image): ?>
                                                    <img src="<?php echo e(asset('storage/'.$item->image)); ?>"
                                                         alt="<?php echo e($item->name); ?>"
                                                         width="100%"
                                                    >
                                                <?php else: ?>
                                                    <img alt="<?php echo e($item->name); ?>"
                                                         src="<?php echo e(asset('assets/images/shop/products/1.jpg')); ?>"
                                                         width="100%"
                                                    >
                                                <?php endif; ?>
                                            </a>
                                        </div>
                                        <div class="product-description">
                                            <div class="product-category">
                                                <?php echo e($item->productCategory? $item->productCategory->name : ''); ?>

                                            </div>
                                            <div class="product-title">
                                                <p class="text-primary"><a href="<?php echo e(route('client.product-detail',$item->slug)); ?>"><?php echo e($item->name); ?></a></p>
                                            </div>
                                            <div class="product-price">
                                                <?php if(!empty($item->productPrices->toArray())): ?>
                                                    <ins><span class="text-danger"><?php echo e(number_format($item->productPrices[0]->price, 0, ',', '.')); ?> VND</span>
                                                    </ins>
                                                <?php else: ?>
                                                    <ins><span class="text-danger">Liên hệ</span></ins>
                                                <?php endif; ?>
                                            </div>
                                            <div class="product-rate">
                                                <i class="fa fa-star"></i>
                                                <i class="fa fa-star"></i>
                                                <i class="fa fa-star"></i>
                                                <i class="fa fa-star"></i>
                                                <i class="fa fa-star-half-o"></i>
                                            </div>
                                        </div>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endif; ?>
                        </div>
                        <!-- end: Product-->

                        <!--widget newsletter-->
                        <div class="widget  widget-newsletter">
                            <form class="widget-subscribe-form form-inline" action="include/subscribe-form.php"
                                  role="form" method="post">
                                <h4 class="widget-title">Đăng ký nhận khuyến mãi</h4>
                                <small>Nhập mail để nhận nhiều mã KM từ BADANGOAI</small>
                                <div class="input-group">
                                    <input type="email" aria-required="true" name="widget-subscribe-form-email"
                                           class="form-control required email" placeholder="Nhập Email...">
                                    <span class="input-group-btn">
                  <button type="submit" id="widget-subscribe-submit-button" class="btn btn-default"><i
                          class="fa fa-paper-plane"></i></button>
                  </span></div>
                            </form>

                        </div>
                        <!--end: widget newsletter-->
                    </div>
                </div>
                <!-- end: Sidebar-->
            </div>
        </div>
    </section>
    <!-- end: Content -->

<?php $__env->stopSection(); ?>

<?php echo $__env->make('client.layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/batdango/public_html/resources/views/client/post/index.blade.php ENDPATH**/ ?>