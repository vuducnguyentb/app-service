<?php $__env->startSection('seo_support'); ?>
    <title><?php echo e(config('batdangoai')['seo']['index-combo']['title']); ?></title>
    <meta name="description" content="<?php echo e(config('batdangoai')['seo']['index-combo']['description']); ?>">
    <meta property="og:image" content="<?php echo e(asset('assets/seo/title/batdangoai.jpg')); ?>">
    <meta name="twitter:image" content="<?php echo e(asset('assets/seo/title/batdangoai.jpg')); ?>">
    <meta property="og:title" content="<?php echo e(config('batdangoai')['seo']['index-combo']['title']); ?>">
    <meta property="og:description" content="<?php echo e(config('batdangoai')['seo']['index-combo']['description']); ?>">
    <meta property="og:url" content="<?php echo e(route('client.combo')); ?>">
    <meta name="twitter:title" content="<?php echo e(config('batdangoai')['seo']['index-combo']['title']); ?>">
    <meta name="twitter:description" content="<?php echo e(config('batdangoai')['seo']['index-combo']['description']); ?>">
    <meta name="twitter:card" content="summary_large_image">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('before_css'); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

    <!-- Page title -->
    <section id="page-title" data-parallax-image="images/parallax/5.jpg">
        <div class="container">
            <div class="page-title">
                <h1>BatDaNgoai</h1>
                <span>Quý khách vui lòng đến cửa hàng nếu muốn thuê nhiều sản phẩm để được giá ưu đãi tốt nhất</span>
            </div>
            <!--<div class="breadcrumb">-->
            <!--    <ul>-->
            <!--        <li><a href="#">Trang chủ</a>-->
            <!--        </li>-->
            <!--        <li><a href="#">Sản phẩm</a>-->
            <!--        </li>-->
            <!--    </ul>-->
            <!--</div>-->
        </div>
    </section>
    <!-- end: Page title -->

    <!-- Shop products -->
    <section id="page-content" class="sidebar-left">
        <div class="container">
            <div class="row">
                <!-- Content-->
                <div class="content col-md-9">
                    <div class="row m-b-20">
                        <div class="col-md-6 p-t-10 m-b-20">

                            <p>Chào mừng bạn đến với dịch vụ thuê bạt dã ngoại của chúng tôi! Chúng tôi cung cấp một loạt các sản phẩm chất lượng cao, đa dạng và hấp dẫn để đảm bảo rằng bạn có những trải nghiệm dã ngoại tuyệt vời nhất.</p>
                        </div>
































                    </div>
                    <!--Product list-->
                    <?php if(!empty($combos->toArray())): ?>
                    <div class="shop">
                        <div class="grid-layout grid-3-columns" data-item="grid-item">
                            <?php $__currentLoopData = $combos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="grid-item">
                                <div class="product">
                                    <div class="product-image">
                                        <a href="<?php echo e(route('client.combo-detail',$item->slug)); ?>">
                                        <?php if($item->image): ?>
                                            <img src="<?php echo e(asset('storage/'.$item->image)); ?>" alt="">
                                        <?php else: ?>
                                                <img alt="Shop product image!" src="<?php echo e(asset('assets/images/shop/products/1.jpg')); ?>">
                                        <?php endif; ?>
                                        </a>


                                        <span class="product-new">Mới</span>






                                    </div>

                                    <div class="product-description">
                                        <div class="product-category"><?php echo e($item->productCategory->name); ?></div>
                                        <div class="product-title">
                                            <p><a href="<?php echo e(route('client.combo-detail',$item->slug)); ?>"><?php echo e($item->name); ?></a></p>
                                        </div>
                                        <div class="product-price">
                                            <?php if(!empty($item->productPrices->toArray())): ?>
                                                <ins><span class="text-danger"><?php echo e(number_format($item->productPrices[0]->price, 0, ',', '.')); ?> VND</span></ins>
                                            <?php else: ?>
                                                <ins class="text-danger">Liên hệ</ins>
                                            <?php endif; ?>
                                        </div>
                                        <div class="product-rate">
                                            <i class="fa fa-star"></i>
                                            <i class="fa fa-star"></i>
                                            <i class="fa fa-star"></i>
                                            <i class="fa fa-star"></i>
                                            <i class="fa fa-star-half-o"></i>
                                        </div>
                                        <div class="product-reviews"><a href="#"><?php echo e($item->views); ?> lượt xem</a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                        <hr>
                        <div>
                            <?php echo e($combos->links('vendor.pagination.bootstrap-4', ['foo' => 'bar'])); ?>

                        </div>
                    </div>
                    <?php endif; ?>
                    <!--End: Product list-->
                </div>
                <!-- end: Content-->

                <!-- Sidebar-->
                <div class="sidebar col-md-3">
                    <!--widget newsletter-->
                    <div class="widget clearfix widget-archive">
                        <h4 class="widget-title">Danh mục combo</h4>
                        <?php if(!empty($categories->toArray())): ?>
                        <ul class="list list-lines">
                            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><a href="<?php echo e(route('client.category-combo',$item->slug)); ?>"><?php echo e($item->name); ?></a> <span class="count">(<?php echo e($item->combos_count); ?>)</span>
                            </li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                        <?php endif; ?>
                    </div>
                    <div class="widget clearfix widget-shop">
                        <h4 class="widget-title">Sản phẩm mới</h4>
                        <?php if(!empty($latestProducts->toArray())): ?>
                        <?php $__currentLoopData = $latestProducts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="product">
                            <div class="product-image">
                                <a href="<?php echo e(route('client.product-detail',$item->slug)); ?>">
                                    <?php if($item->image): ?>
                                        <img src="<?php echo e(asset('storage/'.$item->image)); ?>" alt="<?php echo e($item->name); ?>">
                                    <?php else: ?>
                                        <img src="<?php echo e(asset('assets/images/shop/products/10.jpg')); ?>" alt="<?php echo e($item->name); ?>">
                                    <?php endif; ?>
                                </a>
                            </div>
                            <div class="product-description">
                                <div class="product-category"><?php echo e($item->productCategory->name); ?></div>
                                <div class="product-title">
                                    <p><a href="<?php echo e(route('client.product-detail',$item->slug)); ?>"><?php echo e($item->name); ?></a></p>
                                </div>
                                <div class="product-price">
                                    <?php if(!empty($item->productPrices->toArray())): ?>
                                        <ins><span class="text-danger"><?php echo e(number_format($item->productPrices[0]->price, 0, ',', '.')); ?></span></ins>
                                    <?php else: ?>
                                        <ins class="text-danger">Liên hệ</ins>
                                    <?php endif; ?>
                                </div>
                                <div class="product-rate">
                                    <i class="fa fa-star"></i>
                                    <i class="fa fa-star"></i>
                                    <i class="fa fa-star"></i>
                                    <i class="fa fa-star"></i>
                                    <i class="fa fa-star-half-o"></i>
                                </div>
                            </div>
                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>
                    </div>


                </div>
                <!-- end: Sidebar-->
            </div>
        </div>
    </section>
    <!-- end: Shop products -->


    <!-- DELIVERY INFO -->

















    <!-- end: DELIVERY INFO -->


<?php $__env->stopSection(); ?>

<?php echo $__env->make('client.layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/batdango/public_html/resources/views/client/combo/index.blade.php ENDPATH**/ ?>