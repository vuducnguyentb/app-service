<?php $__env->startSection('before_css'); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <!-- Content Wrapper. Contains page content -->
    <div class="content-wrapper">
        <!-- Content Header (Page header) -->
        <div class="content-header">
            <div class="container-fluid">
                <div class="row mb-2">
                    <div class="col-sm-6">
                        <h1 class="m-0">Cập nhật sản phẩm <?php echo e($product->name); ?></h1>
                    </div><!-- /.col -->
                    <div class="col-sm-6">
                        <ol class="breadcrumb float-sm-right">
                            <li class="breadcrumb-item"><a href="#">Home</a></li>
                            <li class="breadcrumb-item active">Dashboard v2</li>
                        </ol>
                    </div><!-- /.col -->
                </div><!-- /.row -->
            </div><!-- /.container-fluid -->P
        </div>
        <!-- /.content-header -->
        <?php if($errors->any()): ?>
            <div class="alert alert-danger">
                <ul>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
    <?php endif; ?>
    <!-- Main content -->
        <section class="content">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-12 mb-1">
                        <div class="card card-primary">
                            <div class="card-header">
                                
                            </div>
                            <!-- /.card-header -->
                            <!-- form start -->
                            <form method="POST" enctype="multipart/form-data" action="<?php echo e(route('products.update',$product->id)); ?>">
                                <?php echo method_field('PUT'); ?>
                                <input type="hidden" name="_token" id="token" value="<?php echo e(csrf_token()); ?>">
                                <div class="card-body">
                                    <div class="form-group">
                                        <label for="exampleInputEmail1">Code sản phẩm</label>
                                        <input type="text" class="form-control"
                                               id="codeCategory"  name="code" value="<?php echo e($product->code); ?>">
                                    </div>
                                    <div class="form-group">
                                        <label for="exampleInputEmail1">Tên sản phẩm</label>
                                        <input type="text" class="form-control"
                                               id="nameCategory" name="name" value="<?php echo e($product->name); ?>">
                                    </div>
                                    <div class="form-group">
                                        <label for="exampleInputPassword1">Slug</label>
                                        <input type="text" class="form-control"
                                               id="slugCategory" name="slug" value="<?php echo e($product->slug); ?>">
                                    </div>
                                    <div class="form-group">
                                        <?php if($product->image): ?>
                                            <img src="<?php echo e(asset('storage/'.$product->image)); ?>" alt="">
                                        <?php endif; ?>
                                        <div class="form-group note-form-group note-group-select-from-files">
                                            <label for="note-dialog-image-file-17036059093161" class="note-form-label">Select from files</label>
                                            <input id="note-dialog-image-file-17036059093161" class="note-image-input form-control-file note-form-control note-input"
                                                   type="file" name="newimage" accept="image/*" multiple="multiple">
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label for="exampleInputPassword1">Trạng thái</label>
                                        <select class="form-control" name="status">
                                            <option value="active" <?php echo e($product->status == 'active' ? 'selected' :''); ?> >Sử dụng</option>
                                            <option value="in_active" <?php echo e($product->status == 'in_active' ? 'selected' :''); ?>>Ngừng sử dụng</option>
                                        </select>
                                    </div>
                                    <div class="form-group">
                                        <label for="exampleInputPassword1">Có hot không?</label>
                                        <select class="form-control" name="is_hot">
                                            <option value="in_active" <?php echo e($product->is_hot == 'in_active' ? 'selected' :''); ?>>Thường</option>
                                            <option value="active" <?php echo e($product->is_hot == 'active' ? 'selected' :''); ?>>Hot</option>
                                        </select>
                                    </div>
                                    <div class="form-group">
                                        <label for="exampleInputPassword1">FreeShip</label>
                                        <select class="form-control" name="freeship">
                                            <option value="in_active" <?php echo e($product->freeship == 'in_active' ? 'selected' :''); ?>>Không</option>
                                            <option value="active" <?php echo e($product->freeship == 'active' ? 'selected' :''); ?>>Có</option>
                                        </select>
                                    </div>
                                    <div class="form-group">
                                        <label for="exampleInputPassword1">Danh mục </label>
                                        <div class="form-check d-flex justify-content-around">
                                            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <div>
                                                    <input class="form-check-input"
                                                           type="radio"
                                                           name="category"
                                                           value="<?php echo e($category->id); ?>"
                                                        <?php echo e($category->id == $selectedCategory ? 'checked' :''); ?>

                                                    >
                                                    <label class="form-check-label"><?php echo e($category->name); ?></label>
                                                </div>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label for="exampleInputPassword1">Số lượng có</label>
                                        <input type="number" class="form-control"
                                               id="quantityCategory"  name="quantity"
                                        value="<?php echo e($product->quantity); ?>"
                                        >
                                    </div>
                                    <div class="form-group">
                                        <label for="exampleInputPassword1">Nội dung</label>
                                        <textarea name="content" class="form-control my-editor" rows="7"><?php echo old('body', $product->body); ?></textarea>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label for="exampleInputPassword1">Meta Description</label>
                                    <textarea class="form-control" rows="3" placeholder="Enter ..." name="description"><?php echo e(old('meta_description', $product->meta_description)); ?></textarea>
                                </div>
                                <div class="form-group">
                                    <label for="exampleInputPassword1">Meta Keywords</label>
                                    <textarea class="form-control" rows="3" placeholder="Enter ..." name="keywords"><?php echo e(old('meta_keywords', $product->meta_keywords)); ?></textarea>
                                </div>
                                <!-- /.card-body -->

                                <div class="card-footer">
                                    <button type="submit" class="btn btn-primary">Cập nhật</button>
                                </div>
                            </form>
                        </div>
                    </div>
                    <!-- /.col -->
                </div>
                <!-- /.row -->
            </div>
            <!-- /.container-fluid -->
        </section>
        <!-- /.content -->
    </div>
    <!-- /.content-wrapper -->
<?php $__env->stopSection(); ?>
<?php $__env->startSection('after_js'); ?>
    <script src="https://cdn.ckeditor.com/4.6.2/standard/ckeditor.js"></script>
    <script>
        var options = {
            filebrowserImageBrowseUrl: '/laravel-filemanager?type=Images',
            filebrowserImageUploadUrl: '/laravel-filemanager/upload?type=Images&_token=',
            filebrowserBrowseUrl: '/laravel-filemanager?type=Files',
            filebrowserUploadUrl: '/laravel-filemanager/upload?type=Files&_token='
        };
    </script>
    <script>
        CKEDITOR.replace('content', options);
    </script>
    <script>
        jQuery('#nameCategory').keyup(function(){
            var name = $(this).val();
            jQuery.ajax({
                url: "<?php echo e(route('generate.slug')); ?>",
                type: 'POST',
                data: {name: name},
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                },
                success: function(data){
                    $('#slugCategory').val(data.slug);
                }
            });
        });
    </script>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('admin.layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/batdango/public_html/resources/views/admin/product/edit.blade.php ENDPATH**/ ?>