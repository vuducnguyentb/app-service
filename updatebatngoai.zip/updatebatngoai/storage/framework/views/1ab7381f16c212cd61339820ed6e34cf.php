<!DOCTYPE html>
<html lang="en">

<head>
    <?php echo $__env->yieldContent('seo_support'); ?>
    <link rel="shortcut icon" type="image/png" href="<?php echo e(asset('assets/images/favicon.png')); ?>"/>
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <meta http-equiv="content-type" content="text/html; charset=utf-8" />
    <meta name="author" content="BatDaNgoai" />
    <!-- Document title -->
    <!-- Stylesheets & Fonts -->
    <link href="http://fonts.googleapis.com/css?family=Open+Sans:300,400,800,700,600|Montserrat:400,500,600,700|Raleway:100,300,600,700,800" rel="stylesheet" type="text/css" />
    <link href="<?php echo e(asset('assets/css/plugins.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('assets/css/style.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('assets/css/responsive.css')); ?>" rel="stylesheet"> </head>
<?php echo $__env->yieldContent('before_css'); ?>
<body>


<!-- Wrapper -->
<div id="wrapper">

    <!-- TOPBAR -->

<!-- end: TOPBAR -->

    <!-- Header -->
<?php echo $__env->make('client.layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<!-- end: Header -->

<?php echo $__env->yieldContent('content'); ?>

    <!-- Footer -->
<?php echo $__env->make('client.layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<!-- end: Footer -->

</div>
<!-- end: Wrapper -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>
<?php echo $__env->make('client.layouts.contact', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<!-- Go to top button -->
<a id="goToTop"><i class="fa fa-angle-up top-icon"></i><i class="fa fa-angle-up"></i></a>
<!--Plugins-->
<script src="<?php echo e(asset('assets/js/jquery.js')); ?>"></script>
<script src="<?php echo e(asset('assets/js/plugins.js')); ?>"></script>

<!--Template functions-->
<script src="<?php echo e(asset('assets/js/functions.js')); ?>"></script>
</body>

</html>
<?php /**PATH /home/batdango/public_html/resources/views/client/layouts/main.blade.php ENDPATH**/ ?>