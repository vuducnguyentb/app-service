<header id="header" class="header-fullwidth">
    <div id="header-wrap">
        <div class="container">
            <!--Logo-->
            <div id="logo">
                <a href="/" class="logo" data-dark-logo="images/logo-dark.png">
                    <img src="<?php echo e(asset('assets/images/logo.jpg')); ?>" alt="Polo Logo">
                </a>
            </div>
            <!--End: Logo-->

            <!--Top Search Form-->
            <div id="top-search">
                <form action="<?php echo e(route('client.search-product')); ?>" method="POST" enctype="multipart/form-data">
                    <input type="hidden" name="_token" id="token" value="<?php echo e(csrf_token()); ?>">
                    <input type="text" name="searchWord" class="form-control" value="" placeholder="Tìm kiếm sản phẩm.">
                </form>
            </div>
            <!--end: Top Search Form-->

            <!--Header Extras-->
            <div class="header-extras">
                <ul>
                    <li>
                        <!--top search-->
                        <a id="top-search-trigger" href="#" class="toggle-item">
                            <i class="fa fa-search"></i>
                            <i class="fa fa-close"></i>
                        </a>
                        <!--end: top search-->
                    </li>




















                </ul>
            </div>
            <!--end: Header Extras-->

            <!--Navigation Resposnive Trigger-->
            <div id="mainMenu-trigger">
                <button class="lines-button x"> <span class="lines"></span> </button>
            </div>
            <!--end: Navigation Resposnive Trigger-->

            <!--Navigation-->
            <div id="mainMenu" class="light">
                <div class="container">
                    <nav>
                        <ul>
                            <li><a href="/">Trang chủ</a></li>
                            <li class="dropdown"> <a href="<?php echo e(route('client.page','bang-gia-cho-thue')); ?>">Bảng giá cho thuê</a>




                            </li>
                            <li class="dropdown"> <a href="<?php echo e(route('client.combo')); ?>">Gói combo</a>
                                <?php if(!empty($comboCategories->toArray())): ?>
                                <ul class="dropdown-menu">
                                    <?php $__currentLoopData = $comboCategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li ><a href="<?php echo e(route('client.category-combo',$item->slug)); ?>"><i class="fa fa-star"></i><?php echo e($item->name); ?></a>
                                    </li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </ul>
                                <?php endif; ?>
                            </li>
                            <li class="dropdown"> <a href="<?php echo e(route('client.product')); ?>">Sản phẩm</a>
                                <?php if(!empty($productCategories->toArray())): ?>
                                <ul class="dropdown-menu">
                                    <?php $__currentLoopData = $productCategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li ><a href="<?php echo e(route('client.category-product',$item->slug)); ?>"><i class="fa fa-star"></i><?php echo e($item->name); ?></a>
                                    </li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </ul>
                                <?php endif; ?>
                            </li>
                            <li class="dropdown"> <a href="<?php echo e(route('client.page','huong-dan')); ?>">Hướng dẫn</a>




                            </li>
                            <li class="dropdown"> <a href="<?php echo e(route('news')); ?>">Tin tức</a>
                                <?php if(!empty($headerPostCategories->toArray())): ?>
                                    <ul class="dropdown-menu">
                                        <?php $__currentLoopData = $headerPostCategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <li ><a href="<?php echo e(route('category-post',$item->slug)); ?>"><i class="fa fa-newspaper-o"></i><?php echo e($item->name); ?></a>
                                            </li>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </ul>
                                <?php endif; ?>
                            </li>
                        </ul>
                    </nav>
                </div>
            </div>
            <!--end: Navigation-->
        </div>
    </div>
</header>
<?php /**PATH /home/batdango/public_html/resources/views/client/layouts/header.blade.php ENDPATH**/ ?>