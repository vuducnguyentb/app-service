<?php $__env->startSection('seo_support'); ?>
    <title><?php echo e($combo->name); ?></title>
    <meta name="description" content="<?php echo e($combo->meta_description); ?>">
    <meta property="og:title" content="<?php echo e($combo->title); ?>">
    <meta property="og:description" content="<?php echo e($combo->meta_description); ?>">
    <meta property="og:url" content="<?php echo e(route('client.combo-detail',$combo->slug)); ?>">
    <meta name="twitter:title" content=" <?php echo e($combo->name); ?>">
    <meta name="twitter:description" content="<?php echo e($combo->meta_description); ?>">
    <?php if($combo->image): ?>
        <meta property="og:image" content="<?php echo e(asset('storage/'.$combo->image)); ?>">
        <meta name="twitter:image" content="<?php echo e(asset('storage/'.$combo->image)); ?>">
    <?php else: ?>
        <meta name="twitter:image" content="<?php echo e(asset('assets/seo/title/batdangoai.jpg')); ?>">
        <meta property="og:image" content="<?php echo e(asset('assets/seo/title/batdangoai.jpg')); ?>">
    <?php endif; ?>
    <meta name="twitter:card" content="summary_large_image">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('before_css'); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

    <!-- Page title -->
    <section id="page-title" data-parallax-image="images/parallax/5.jpg">
        <div class="container">
            <div class="page-title">
                <h1>Combo</h1>
                <span>Chi tiết <?php echo e($combo->name); ?></span>
            </div>










        </div>
    </section>
    <!-- end: Page title -->

    <!-- SHOP PRODUCT PAGE -->
    <section id="product-page" class="product-page p-b-0">
        <div class="container">
            <div class="product">
                <div class="row m-b-40">
                    <div class="col-md-5">
                        <div class="product-image">
                            <?php if($combo->image): ?>
                                <img src="<?php echo e(asset('storage/'.$combo->image)); ?>" alt="" style="width: 100%">
                            <?php else: ?>
                                <img src="<?php echo e(asset('assets/images/shop/products/product-large.jpg')); ?>" alt="" style="width: 100%">
                            <?php endif; ?>
                        </div>
                    </div>


                    <div class="col-md-7">
                        <div class="product-description">
                            <div class="product-category"><?php echo e($combo->productCategory->name); ?></div>
                            <div class="product-title">
                                <h3><?php echo e($combo->name); ?></h3>
                            </div>
                            <div class="product-price">
                                <?php if(!empty($combo->productPrices->toArray())): ?>
                                    <ins><span class="text-danger"><?php echo e(number_format($combo->productPrices[0]->price, 0, ',', '.')); ?> VND</span></ins>
                                <?php else: ?>
                                    <ins><span class="text-danger">Liên hệ</span></ins>
                                <?php endif; ?>
                            </div>
                            <div class="product-rate">
                                <i class="fa fa-star"></i>
                                <i class="fa fa-star"></i>
                                <i class="fa fa-star"></i>
                                <i class="fa fa-star"></i>
                                <i class="fa fa-star-half-o"></i>
                            </div>
                            <div class="product-reviews"><a href="#"><?php echo e($combo->views); ?> lượt xem</a>
                            </div>

                            <div class="seperator m-b-10"></div>
                            <p><?php echo e($combo->meta_description); ?></p>
                            <div class="product-meta">







                            </div>
                            <div class="seperator m-t-20 m-b-10"></div>

                        </div>
                        <div class="row">
















                        </div>


                    </div>
                </div>

                <div id="tabs-1" class="tabs simple">
                    <ul class="tabs-navigation">
                        <li class="active"><a href="#tab1"><i class="fa fa-align-justify"></i>Chi tiết</a> </li>


                    </ul>
                    <div class="tabs-content">
                        <div class="tab-pane active" id="tab1">
                            <p><?php echo $combo ->body; ?></p>
                        </div>










                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- end: SHOP PRODUCT PAGE -->

    <!-- SHOP WIDGET PRODUTCS -->
    <section class="p-t-0">
        <div class="container">
            <div class="heading-fancy heading-line text-center">
                <h4>Sản phẩm - Combo liên quan!</h4>
            </div>
            <div class="row">
                <div class="col-md-6">


                    <div class="widget-shop">
                        <?php if(!empty($relatedCombos->toArray())): ?>
                        <?php $__currentLoopData = $relatedCombos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="product">
                                <div class="product-image">
                                    <a href="#">
                                        <?php if($item->image): ?>
                                            <img src="<?php echo e(asset('storage/'.$item->image)); ?>" alt="<?php echo e($item->name); ?>">
                                        <?php else: ?>
                                            <img src="<?php echo e(asset('assets/images/shop/products/10.jpg')); ?>"
                                                 alt="<?php echo e($item->name); ?>">
                                        <?php endif; ?>
                                    </a>
                                </div>
                                <div class="product-description">
                                    <div class="product-category"><?php echo e($item->productCategory->name); ?></div>
                                    <div class="product-title">
                                        <p><a href="<?php echo e(route('client.combo-detail',$item->slug)); ?>"><?php echo e($item->name); ?></a></p>
                                    </div>
                                    <div class="product-price">
                                        <?php if(!empty($item->productPrices->toArray())): ?>
                                            <ins><span class="text-danger"><?php echo e(number_format($item->productPrices[0]->price, 0, ',', '.')); ?></span></ins>
                                        <?php else: ?>
                                            <ins class="text-danger">Liên hệ</ins>
                                        <?php endif; ?>
                                    </div>
                                    <div class="product-rate">
                                        <i class="fa fa-star"></i>
                                        <i class="fa fa-star"></i>
                                        <i class="fa fa-star"></i>
                                        <i class="fa fa-star"></i>
                                        <i class="fa fa-star-half-o"></i>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>
                    </div>
                </div>
                <div class="col-md-6">


                    <div class="widget-shop">
                        <?php if(!empty($products->toArray())): ?>
                        <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="product">
                                <div class="product-image">
                                    <a href="#">
                                        <?php if($item->image): ?>
                                            <img src="<?php echo e(asset('storage/'.$item->image)); ?>" alt="<?php echo e($item->name); ?>">
                                        <?php else: ?>
                                            <img src="<?php echo e(asset('assets/images/shop/products/10.jpg')); ?>"
                                                 alt="<?php echo e($item->name); ?>">
                                        <?php endif; ?>
                                    </a>
                                </div>
                                <div class="product-description">
                                    <div class="product-category"><?php echo e($item->productCategory->name); ?></div>
                                    <div class="product-title">
                                        <p><a href="<?php echo e(route('client.product-detail',$item->slug)); ?>"><?php echo e($item->name); ?></a></p>
                                    </div>
                                    <div class="product-price">
                                        <?php if(!empty($item->productPrices->toArray())): ?>
                                            <ins><span class="text-danger"><?php echo e(number_format($item->productPrices[0]->price, 0, ',', '.')); ?></span></ins>
                                        <?php else: ?>
                                            <ins class="text-danger">Liên hệ</ins>
                                        <?php endif; ?>
                                    </div>
                                    <div class="product-rate">
                                        <i class="fa fa-star"></i>
                                        <i class="fa fa-star"></i>
                                        <i class="fa fa-star"></i>
                                        <i class="fa fa-star"></i>
                                        <i class="fa fa-star-half-o"></i>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>
                    </div>
                </div>

            </div>
        </div>
    </section>
    <!-- end: SHOP WIDGET PRODUTCS -->









































<?php $__env->stopSection(); ?>

<?php echo $__env->make('client.layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/batdango/public_html/resources/views/client/combo/detail.blade.php ENDPATH**/ ?>