<?php


namespace App\Http\Controllers\Base;


use App\Http\Controllers\Traits\ResultHandlerTrait;

class BaseWebController extends \App\Http\Controllers\Controller
{
    use ResultHandlerTrait;
}
