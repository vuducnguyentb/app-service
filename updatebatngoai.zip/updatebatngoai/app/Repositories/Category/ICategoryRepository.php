<?php


namespace App\Repositories\Category;


interface ICategoryRepository
{

}
