<?php


namespace App\Repositories\Invoice;


interface IInvoiceRepository extends \App\Repositories\Interfaces\IBaseRepository
{

}
