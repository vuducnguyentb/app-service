<?php


namespace App\Repositories\ProductCategory;


interface IProductCategoryRepository extends \App\Repositories\Interfaces\IBaseRepository
{

}
