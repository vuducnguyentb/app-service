<?php


namespace App\Repositories\Combo;


interface IComboRepository extends \App\Repositories\Interfaces\IBaseRepository
{

}
