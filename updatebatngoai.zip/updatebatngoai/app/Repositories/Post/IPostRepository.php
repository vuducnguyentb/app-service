<?php


namespace App\Repositories\Post;


interface IPostRepository extends \App\Repositories\Interfaces\IBaseRepository
{

}
