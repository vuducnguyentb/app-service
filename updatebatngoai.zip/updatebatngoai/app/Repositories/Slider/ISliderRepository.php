<?php


namespace App\Repositories\Slider;


interface ISliderRepository extends \App\Repositories\Interfaces\IBaseRepository
{

}
