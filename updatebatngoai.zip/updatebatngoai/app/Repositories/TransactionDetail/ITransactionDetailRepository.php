<?php


namespace App\Repositories\TransactionDetail;


interface ITransactionDetailRepository extends \App\Repositories\Interfaces\IBaseRepository
{

}
