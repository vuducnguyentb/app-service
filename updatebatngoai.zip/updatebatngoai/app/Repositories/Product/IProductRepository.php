<?php


namespace App\Repositories\Product;


interface IProductRepository extends \App\Repositories\Interfaces\IBaseRepository
{

}
