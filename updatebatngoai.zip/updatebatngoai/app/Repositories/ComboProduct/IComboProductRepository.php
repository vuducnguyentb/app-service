<?php


namespace App\Repositories\ComboProduct;


interface IComboProductRepository extends \App\Repositories\Interfaces\IBaseRepository
{

}
