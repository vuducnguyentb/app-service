<?php


namespace App\Repositories\Page;


interface IPageRepository extends \App\Repositories\Interfaces\IBaseRepository
{

}
