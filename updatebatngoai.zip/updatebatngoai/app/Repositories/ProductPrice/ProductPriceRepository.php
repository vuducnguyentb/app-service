<?php


namespace App\Repositories\ProductPrice;


class ProductPriceRepository extends \App\Repositories\BaseRepository implements IProductPriceRepository
{

}
