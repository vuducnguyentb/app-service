<?php


namespace App\Repositories\ProductPrice;


interface IProductPriceRepository extends \App\Repositories\Interfaces\IBaseRepository
{

}
