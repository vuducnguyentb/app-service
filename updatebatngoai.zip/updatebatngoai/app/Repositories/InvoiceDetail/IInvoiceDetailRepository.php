<?php


namespace App\Repositories\InvoiceDetail;


interface IInvoiceDetailRepository extends \App\Repositories\Interfaces\IBaseRepository
{

}
