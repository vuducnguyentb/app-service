<?php


namespace App\Repositories\ListSlider;


interface IListSliderRepository extends \App\Repositories\Interfaces\IBaseRepository
{

}
